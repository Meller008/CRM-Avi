CREATE TRIGGER `material_supplyposition_AFTER_INSERT`
AFTER INSERT ON `material_supplyposition`
FOR EACH ROW
  BEGIN
	INSERT INTO material_balance SET Material_SupplyPositionId = NEW.Id, BalanceWeight = NEW.Weight;
END