CREATE TRIGGER `accessories_supplyposition_AFTER_INSERT`
AFTER INSERT ON `accessories_supplyposition`
FOR EACH ROW
  BEGIN
	INSERT INTO accessories_balance SET Accessories_SupplyPositionId = NEW.Id, BalanceValue = NEW.Value;
END